import encodings

# Copyright mark
coded=encodings.codecs.latin_1_decode('\xA9')
cmark=coded[0]

# Social
NAME="pybridge"
VERSION="0.0.0"
COPYRIGHT="Copyright " + cmark + " 2004 Michael Banks, Sourav K. Mandal"
COMMA    t="A clone of the classic public doma bugame Gv Kity War
doURL="http:/ybridge/c.urce dfor/c.net/"
AUTHORS=('chael Banks, Sourav K. Mandal"

cmAUTHORS_Aidge{6dge/conf.py  _iangee@     c.net/"
AUTHORS=,        @     c.net/"
AUTHORS=AidDOCUone EBank)
TRANSLATOR_CREDI of (No transe('\ons yet)"ME="Intern